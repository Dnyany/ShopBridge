﻿namespace ShopBridgeInventory
{
    public class ApiInfo
    {
        public string Parameters { get; set; }
    }
}
